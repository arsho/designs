// Test that C++ programs can run

#include <iostream>

int main(void) {
	std::cout << "Hello, C++ world" << std::endl;
	return 0;
}

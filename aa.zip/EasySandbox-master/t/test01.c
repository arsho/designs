/* First test program - does nothing but return.
 * Should work trivially. */

int main(void)
{
	return 0;
}
